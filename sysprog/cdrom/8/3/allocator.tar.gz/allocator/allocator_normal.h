#ifndef ALLOCATOR_NORMAL_H
#define ALLOCATOR_NORMAL_H
#include "allocator.h"

DECLS_BEGIN

Allocator* allocator_normal_create(void);

DECLS_END

#endif/*ALLOCATOR_NORMAL_H*/

