/* Basic file operations, now *with* sysroot.
#sim: --sysroot=@exedir@
*/
#define PREFIX "/"
#include "openpf3.c"
