/* Simulator options:
#sim: --sysroot=@exedir@/
*/
#include "seek1.c"
